% ID6003W:AI IN PROCESS & LOGISTIC OPTIMIZATION
% MID SEM
% COURSE INSTRUCTOR: DR S RANGANATHAN 
% PREPARED BY: ALOY BANERJEE
% ROLL NUMBER: CH22M503

% Q3. 
% Define the open-loop system
openLoopSys = tf(1, [1 5 4 0]);

% Design and simulation of Proportional (P) controller
[P_controller, P_info] = pidtune(openLoopSys, 'P');
disp('Details for Proportional (P) Controller:');
P_controller
P_info
closedLoop_P = feedback(openLoopSys*P_controller, 1);

% Design and simulation of Integral (I) controller
[I_controller, I_info] = pidtune(openLoopSys, 'I');
disp('Details for Integral (I) Controller:');
I_controller
I_info
closedLoop_I = feedback(openLoopSys*I_controller, 1);

% Design and simulation of Proportional-Integral (PI) controller
[PI_controller, PI_info] = pidtune(openLoopSys, 'PI');
disp('Details for Proportional-Integral (PI) Controller:');
PI_controller
PI_info
closedLoop_PI = feedback(openLoopSys*PI_controller, 1);

% Design and simulation of Proportional-Derivative (PD) controller
[PD_controller, PD_info] = pidtune(openLoopSys, 'PD');
disp('Details for Proportional-Derivative (PD) Controller:');
PD_controller
PD_info
closedLoop_PD = feedback(openLoopSys*PD_controller, 1);

% Design and simulation of Proportional-Integral-Derivative (PID) controller
[PID_controller, PID_info] = pidtune(openLoopSys, 'PID');
disp('Details for Proportional-Integral-Derivative (PID) Controller:');
PID_controller
PID_info
closedLoop_PID = feedback(openLoopSys*PID_controller, 1);

% Plot step-responses for different controller configurations
figure;
subplot(3,2,1)
step(closedLoop_P)
title('Response with Proportional (P) Controller')

subplot(3,2,2)
step(closedLoop_I)
title('Response with Integral (I) Controller')

subplot(3,2,3)
step(closedLoop_PI)
title('Response with Proportional-Integral (PI) Controller')

subplot(3,2,4)
step(closedLoop_PD)
title('Response with Proportional-Derivative (PD) Controller')

subplot(3,2,5)
step(closedLoop_PID)
title('Response with Proportional-Integral-Derivative (PID) Controller')

% Comparison of step-responses
figure;
step(closedLoop_PI, closedLoop_PD, closedLoop_PID, 'r--');
title('Comparison of Responses');
legend({'With PI Controller', 'With PD Controller', 'With PID Controller'}, 'Location', 'southeast');

% Displaying step response information
disp('Response Information with Proportional (P) Controller:')
stepinfo(closedLoop_P)

disp('Response Information with Integral (I) Controller:')
stepinfo(closedLoop_I)

disp('Response Information with Proportional-Integral (PI) Controller:')
stepinfo(closedLoop_PI)

disp('Response Information with Proportional-Derivative (PD) Controller:')
stepinfo(closedLoop_PD)

disp('Response Information with Proportional-Integral-Derivative (PID) Controller:')
stepinfo(closedLoop_PID)






