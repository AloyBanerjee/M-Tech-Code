% Define the name of the Simulink model to be loaded.
model = 'PIDTuningModel';
% Open the Simulink model specified by the variable 'model'.
open_system(model);

% Initialize the proportional gain starting value to zero.
Kp = 0;
% Initialize a variable to store the critical gain, set to zero initially.
Ku = 0;
% Initialize a variable to store the oscillation period, set to zero initially.
Pu = 0;

% Define the total simulation time in seconds.
simTime = 1000;
% Define the threshold number of sign changes in the signal to detect oscillation.
threshold = 8;

% Begin a loop to incrementally increase Kp to find the critical gain Ku.
while Ku == 0
    % Increment the proportional gain Kp by 0.1.
    Kp = Kp + 0.1;

    % Set the proportional gain in the PID controller block within the Simulink model to the current Kp value.
	set_param([model '/PID Controller 1'], 'P', num2str(Kp));
    % set_param([model '/PID Controller 2'], 'P', num2str(Kp));
    
    % Run the simulation of the model up to the specified simulation time.
    simOut = sim(model, 'StopTime', num2str(simTime));

    % Retrieve the logged output signal data from the simulation output.
    outputSignal_data = simOut.logsout.get('PID1_Signal');
	%outputSignal_data = simOut.logsout.get('PID2_Signal');
    % Extract the signal values from the output signal data.
    outputSignal = outputSignal_data.Values.Data;
    % Extract the time vector corresponding to the signal values.
    timeVector = outputSignal_data.Values.Time;

    % Compute the difference between consecutive signal values.
    diffs = diff(outputSignal);
    % Count the number of times the sign of the difference between consecutive signal values changes.
    signChanges = sum(diff(sign(diffs)) ~= 0);

    % If the number of sign changes exceeds the threshold, set Ku to the current Kp value.
    if signChanges > threshold
        Ku = Kp;
    end
end

% Find the local maxima (peaks) in the output signal.
[peaks, locs] = findpeaks(outputSignal);
% If at least two peaks are found, calculate Pu as the time difference between the first two peaks.
if length(peaks) >= 2
    Pu = timeVector(locs(2)) - timeVector(locs(1));
else
    % If not enough peaks are found, throw an error indicating the oscillation period cannot be determined.
    error('Not enough peaks to determine oscillation period.');
end

% Calculate the Ziegler-Nichols tuned PID parameters using the critical gain Ku and oscillation period Pu.
Kp_ZN = 0.6 * Ku; % Proportional gain
Ki_ZN = 2 * Kp_ZN / Pu; % Integral gain
Kd_ZN = Kp_ZN * Pu / 8; % Derivative gain

% Apply the calculated Ziegler-Nichols tuned PID parameters to the PID controller block in the Simulink model.
set_param([model '/PID Controller 1'], 'P', num2str(Kp_ZN));
set_param([model '/PID Controller 1'], 'I', num2str(Ki_ZN));
set_param([model '/PID Controller 1'], 'D', num2str(Kd_ZN));

% Optionally close the Simulink model without saving changes.
close_system(model);
