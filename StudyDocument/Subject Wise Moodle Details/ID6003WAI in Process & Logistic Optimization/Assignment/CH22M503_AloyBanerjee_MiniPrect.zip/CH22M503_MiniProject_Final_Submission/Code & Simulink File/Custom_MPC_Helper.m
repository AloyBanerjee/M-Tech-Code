function [A, B, C, D] = Custom_MPC_Helper()
    % Define the plant constants
    a = 0.089189768;
    b = 28.411996219008245;
    c = 1.2492990778156785;
    d = 0.282942411;
    h = 0.027577205;
    p = 0.384850147;
    m = 122.56405414735806;
    n = 0.28019177500177966;

    % Create the transfer functions
    s = tf('s');
    G11 = a / (b*s + c);
    G12 = d / (2547.77*s^2 + 90.75*s + 1);
    G21 = h / (259*s^2 + 17.09*s + 1);
    G22 = p / (m*s + n);

    % Combine into a TITO system
    G = [G11 G12; G21 G22];

    % Convert to state-space
    plant_ss = ss(G);

    % Extract state-space matrices
    [A, B, C, D] = ssdata(plant_ss);

    % Display the matrices in the MATLAB command window
    disp('Matrix A:');
    disp(A);
    
    disp('Matrix B:');
    disp(B);
    
    disp('Matrix C:');
    disp(C);
    
    disp('Matrix D:');
    disp(D);
end
