% Clear all variables and close all figures
clear

% Set the sampling time
Ts = 1;

% Define the number of step response coefficients
Ncoeffs = 200;

% Define transfer functions for the system models
g11 = poly2tfd([0.089189768], [28.411996219008245 1.2492990778156785], 0, 0); % Transfer function for g11
g21 = poly2tfd([0.027577205], [259 17.09 1], 0, 0); % Transfer function for g21
g12 = poly2tfd([0.282942411], [2547.77 90.75 1], 0, 0); % Transfer function for g12
g22 = poly2tfd([0.384850147], [122.56405414735806 0.28019177500177966], 0, 0); % Transfer function for g22
gd1 = poly2tfd(3.8, [14.9 1], 0, 8.1); % Transfer function for gd1
gd2 = poly2tfd(4.9, [13.2 1], 0, 3.4); % Transfer function for gd2

% Define the final time for the model horizon
tfinal = 100;

% Define the delta (time step) for the model
delt = 1;

% Define the number of outputs
ny = 2;

% Calculate step response coefficients for the transfer functions
Step_Coeff = tfd2step(tfinal, delt, ny, g11, g21, g12, g22);

% Calculate step response coefficients for the scaled transfer functions
Sp = tfd2step(tfinal, delt, ny, 0.8 * g11, 0.8 * g21, 0.8 * g12, 0.8 * g22);

% Define the prediction horizon
P = 15;

% Define the control horizon
M = 10;

% Set the setpoint for each step into the future
ysp = 1 * ones(P, 1);

% Define the number of simulation steps
Nsim = 100;

% Calculate the total simulation time
t_sim = Nsim * Ts;

% Initialize the actual time
t_act = 0;

% Initialize an array to store simulation time points
time_sim = t_act;

% Initialize error terms for model plant mismatch
err_k1 = 0;
err_k2 = 0;

% Initialize prediction matrix S1
S1 = zeros(P, M);
for i = 1:P
    cnt = 1;
    for j = i:-1:max(1, i - M + 1)
        S1(i, cnt) = Step_Coeff(j, 1);
        cnt = cnt + 1;
    end
end

% Initialize prediction matrix S2
S2 = zeros(P, M);
for i = 1:P
    cnt = 1;
    for j = i:-1:max(1, i - M + 1)
        S2(i, cnt) = Step_Coeff(j, 2);
        cnt = cnt + 1;
    end
end

% Define Q and R matrices for weighting the output and control moves
Q1 = 100 * diag(ones(P, 1));
Q2 = 400 * diag(ones(P, 1));
R1 = 0.01 * diag(ones(M, 1));
R2 = 0.001 * diag(ones(M, 1));

% Main simulation loop
for k = 1:Nsim
    % Loop over the prediction horizon
    for ii = 1:P
        free_resp1 = 0;
        free_resp2 = 0;
        % Loop to calculate free response for each output
        for i = ii + 1:Ncoeffs - 1
            ind = k + ii - i;
            if ind > 0
                free_resp1 = free_resp1 + Step_Coeff(i, 1) * du_steps1(ind);
                free_resp2 = free_resp2 + Step_Coeff(i, 2) * du_steps2(ind);
            else
                break;
            end
        end
        if k + ii - Ncoeffs > 0
            free_resp1 = free_resp1 + Step_Coeff(Ncoeffs, 1) * u_steps1(k + ii - Ncoeffs);
            free_resp2 = free_resp2 + Step_Coeff(Ncoeffs, 2) * u_steps2(k + ii - Ncoeffs);
        end

        % Adjust free response for model-plant mismatch
        free_resp1 = free_resp1 + err_k1(k);
        free_resp2 = free_resp2 + err_k2(k);

        % Store the predicted outputs
        ypred1(ii) = free_resp1;
        ypred2(ii) = free_resp2;
    end

    % Calculate the control error
    E_k1 = ysp - ypred1';
    E_k2 = ysp - ypred2';

    % Calculate the control move
    Du_k1 = inv(S1' * Q1 * S1 + R1) * S1' * Q1 * E_k1;
    Du_k2 = inv(S2' * Q2 * S2 + R2) * S2' * Q2 * E_k2;

    % Implement the first control move
    du1 = Du_k1(1);
    du2 = Du_k2(1);
    du_steps1(k) = du1;
    du_steps2(k) = du2;
    if k - 1 > 0
        u_k1 = u_steps1(k - 1) + du1;
        u_k2 = u_steps2(k - 1) + du2;
    else
        u_k1 = du1;
        u_k2 = du2;
    end
    u_steps1(k) = u_k1;
    u_steps2(k) = u_k2;

    % Loop to calculate the actual plant output
    J1 = 1;
    k1 = k + 1;
    ymeas1 = 0;
    ymeas2 = 0;
    for i = J1 + 1:Ncoeffs - 1
        if k1 + J1 - i > 0
            ymeas1 = ymeas1 + Sp(i, 1) * du_steps1(k1 + J1 - i);
            ymeas2 = ymeas2 + Sp(i, 2) * du_steps2(k1 + J1 - i);
        else
            break;
        end
    end
    if k1 + J1 - Ncoeffs > 0
        ymeas1 = ymeas1 + Sp(Ncoeffs, 1) * u_steps1(k1 + J1 - Ncoeffs);
        ymeas2 = ymeas2 + Sp(Ncoeffs, 2) * u_steps2(k1 + J1 - Ncoeffs);
    end
    yplant1(k) = ymeas1;
    yplant2(k) = ymeas2;

    % Calculate the prediction error for the next step
    ypred_1_1 = 0;
    ypred_1_2 = 0;
    for i = J1 + 1:Ncoeffs - 1
        if k1 + J1 - i > 0
            ypred_1_1 = ypred_1_1 + Step_Coeff(i, 1) * du_steps1(k1 + J1 - i);
            ypred_1_2 = ypred_1_2 + Step_Coeff(i, 2) * du_steps2(k1 + J1 - i);
        else
            break;
        end
    end
    if k1 + J1 - Ncoeffs > 0
        ypred_1_1 = ypred_1_1 + Step_Coeff(Ncoeffs, 1) * u_steps1(k1 + J1 - Ncoeffs);
        ypred_1_2 = ypred_1_2 + Step_Coeff(Ncoeffs, 2) * u_steps2(k1 + J1 - Ncoeffs);
    end

    % Update the model-plant mismatch error
    err_k1(k + 1) = ymeas1 - ypred_1_1;
    err_k2(k + 1) = ymeas2 - ypred_1_2;

    % Update the actual time
    t_act = t_act + Ts;
    time_sim = [time_sim t_act];
end

% Plot the control moves for the first output
figure
subplot(311)
stairs(time_sim, [0 u_steps1])
title('u - control moves')

% Plot the process output for the first output
subplot(312)
plot(time_sim, [0 yplant1])
xlabel('Time in minutes')
title('y - process output')

% Plot the model plant error for the first output
% subplot(313)
% plot(time_sim, [err_k1])
% xlabel('Time in minutes')
% title('Model plant error')

% Plot the control moves for the second output
figure
subplot(311)
stairs(time_sim, [0 u_steps2])
title('u - control moves')

% Plot the process output for the second output
subplot(312)
plot(time_sim, [0 yplant2])
plot(time_sim, [0 yplant2])
xlabel('Time in minutes')
title('y - process output')


% Plot the model plant error for the second output
% subplot(313)
% plot(time_sim, [err_k2])
% xlabel('Time in minutes')
% title('Model plant error')