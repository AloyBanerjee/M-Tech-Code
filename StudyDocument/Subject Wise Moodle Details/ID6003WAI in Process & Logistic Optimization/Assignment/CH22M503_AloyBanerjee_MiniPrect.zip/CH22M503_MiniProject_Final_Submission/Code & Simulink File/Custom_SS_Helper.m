function [plant] = Custom_SS_Helper()
     % Matrix A
    A = [-0.0440         0         0         0         0         0;
              0 -0.0660 -0.0618         0         0         0;
              0  0.0625         0         0         0         0;
              0         0 -0.0356 -0.0251         0         0;
              0         0         0  0.0156         0         0;
              0         0         0         0 -0.0023         0];
    
    % Matrix B
    B = [ 0.0625         0;
          0.0312         0;
               0         0;
               0  0.0625;
               0         0;
               0  0.0625];
    
    % Matrix C
    C = [0.0502         0         0         0  0.1137         0;
              0         0  0.0545         0         0  0.0502];
    
    % Matrix D
    D = [0         0;
              0         0];
    % Create the state-space object with the provided matrices
    plant = ss(A, B, C, D, 1);  % Assuming a sample time of 1

    disp('Plant:');
    disp(plant);
end